<?php
require_once 'db.php';
require_once 'pedido.php';

$platos = obtenerPlatos($pdo);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrito de Compras</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    <h1>Carrito de Compras</h1>
    <form method="post" action="index.php">
        <input type="hidden" name="accion" value="añadir">
        <label for="plato">Seleccionar Plato:</label>
        <select id="plato" name="idPlato" required>
            <option value="" disabled selected>Selecciona un plato</option>
            <?php foreach ($platos as $plato): ?>
                <option value="<?= $plato->id ?>" <?= $plato->cantidad == 0 ? 'disabled' : '' ?>>
                    <?= htmlspecialchars($plato->nombre) ?> - <?= number_format($plato->precio, 2) ?>€ (<?= $plato->cantidad ?> disponibles)
                </option>
            <?php endforeach; ?>
        </select>
        <button type="submit">Añadir al Carrito</button>
    </form>

    <h2>Platos en el Carrito</h2>
    <table>
        <thead>
        <tr>
            <th>Nombre</th>
            <th>Precio</th>
            <th>Acción</th>
        </tr>
        </thead>
        <tbody>
        <?php if (!empty($_SESSION['carrito'])): ?>
            <?php foreach ($_SESSION['carrito'] as $plato): ?>
                <tr>
                    <td><?= htmlspecialchars($plato->nombre) ?></td>
                    <td><?= number_format($plato->precio, 2) ?>€</td>
                    <td>
                        <form method="post" action="index.php" style="display:inline;">
                            <input type="hidden" name="accion" value="eliminar">
                            <input type="hidden" name="idPlato" value="<?= $plato->idPlato ?>">
                            <button type="submit">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="3">El carrito está vacío.</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>

    <div class="total">
        <h3>Total: <?= number_format(calcularTotal(), 2) ?>€</h3>
    </div>

    <form method="post" action="index.php">
        <input type="hidden" name="accion" value="generar_ticket">
        <button type="submit">Generar Ticket</button>
    </form>

    <div class="ticket">
        <?php
        if (isset($ticket)) {
            echo $ticket;
        }
        ?>
    </div>
</div>

</body>
</html>
