<?php
require_once 'db.php';
require_once 'plato.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accion = $_POST['accion'] ?? '';

    if ($accion === 'añadir' && isset($_POST['idPlato'])) {
        $idPlato = $_POST['idPlato'];

        // Obtener el plato de la base de datos
        $stmt = $pdo->prepare("SELECT * FROM platos WHERE id = :id");
        $stmt->execute(['id' => $idPlato]);
        $resultado = $stmt->fetch(PDO::FETCH_OBJ);

        if ($resultado) {
            if ($resultado->cantidad > 0) {
                // Crear una instancia de Plato
                $plato = new Plato($resultado->id, $resultado->nombre, $resultado->precio, $resultado->cantidad);
                $_SESSION['carrito'][] = $plato;

                // Reducir la cantidad disponible en la base de datos
                $updateStmt = $pdo->prepare("UPDATE platos SET cantidad = cantidad - 1 WHERE id = :id");
                $updateStmt->execute(['id' => $idPlato]);
            } else {
                echo "No hay suficiente cantidad de este plato.";
            }
        } else {
            echo "Plato no encontrado.";
        }
    } elseif ($accion === 'eliminar' && isset($_POST['idPlato'])) {
        $idPlatoEliminar = $_POST['idPlato'];

        foreach ($_SESSION['carrito'] as $key => $plato) {
            if ($plato->idPlato == $idPlatoEliminar) {
                unset($_SESSION['carrito'][$key]);
                $_SESSION['carrito'] = array_values($_SESSION['carrito']); // Reindexar el array

                // Incrementar la cantidad disponible en la base de datos
                $updateStmt = $pdo->prepare("UPDATE platos SET cantidad = cantidad + 1 WHERE id = :id");
                $updateStmt->execute(['id' => $idPlatoEliminar]);

                break;
            }
        }
    } elseif ($accion === 'generar_ticket') {
        // Generar el ticket
        $ticket = generarTicket();
    }
}

// Función para obtener todos los platos disponibles
function obtenerPlatos($pdo) {
    $stmt = $pdo->query("SELECT * FROM platos");
    return $stmt->fetchAll(PDO::FETCH_OBJ);
}

// Función para calcular el total del carrito
function calcularTotal() {
    $total = 0;
    foreach ($_SESSION['carrito'] as $plato) {
        $total += $plato->precio;
    }
    return $total;
}

// Función para generar el ticket
function generarTicket() {
    $ticket = "<h3>--- TICKET ---</h3>";
    foreach ($_SESSION['carrito'] as $plato) {
        $ticket .= htmlspecialchars($plato->nombre) . " - " . number_format($plato->precio, 2) . "€<br>";
    }
    $ticket .= "Total: " . number_format(calcularTotal(), 2) . "€";
    return $ticket;
}
?>
