<?php
class Plato {
    public $idPlato;
    public $nombre;
    public $precio;
    public $cantidad; // Nueva propiedad

    public function __construct($id, $nombre, $precio, $cantidad) {
        $this->idPlato = $id;
        $this->nombre = $nombre;
        $this->precio = $precio;
        $this->cantidad = $cantidad;
    }
}
?>
