-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 25-11-2024 a las 18:11:53
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `carrito_compras`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `platos`
--

CREATE TABLE `platos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `cantidad` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `platos`
--

INSERT INTO `platos` (`id`, `nombre`, `precio`, `cantidad`) VALUES
(16, 'tacos', 10.00, 5),
(17, 'tacos de tripas', 10.00, 10),
(18, 'Tacos de al pastor, con cebolla', 15.00, 20),
(19, 'Tacos de al pastor, sin cebolla', 15.00, 20),
(20, 'Tacos de al pastor, solos', 14.00, 20),
(21, 'Tacos de carne asada, con todo', 18.00, 20),
(22, 'Tacos de carne asada, sin cilantro', 18.00, 19),
(23, 'Tacos de carne asada, solos', 17.00, 20),
(24, 'Tacos de suadero, con todo', 20.00, 20),
(25, 'Tacos de suadero, sin salsa', 20.00, 20),
(26, 'Tacos de suadero, solos', 19.00, 20),
(27, 'Tacos de tripa, dorados, con todo', 22.00, 20),
(28, 'Tacos de tripa, suaves, sin cebolla', 22.00, 20),
(29, 'Tacos de tripa, solos', 21.00, 18),
(30, 'Tacos de barbacoa, con todo', 25.00, 20),
(31, 'Tacos de barbacoa, sin salsa', 25.00, 20),
(32, 'Tacos de barbacoa, solos', 24.00, 20),
(33, 'Tacos de lengua, con todo', 30.00, 20),
(34, 'Tacos de lengua, sin cilantro', 30.00, 20),
(35, 'Tacos de lengua, solos', 28.00, 20),
(36, 'Tacos de chicharrón, con todo', 18.00, 20),
(37, 'Tacos de chicharrón, sin cebolla', 18.00, 20);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `platos`
--
ALTER TABLE `platos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `platos`
--
ALTER TABLE `platos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
