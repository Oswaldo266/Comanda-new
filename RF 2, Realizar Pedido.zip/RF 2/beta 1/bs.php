<?php
function conectar() {
    $host = 'localhost';
    $dbname = 'carrito_compras';
    $user = 'root';
    $password = '';

    try {
        return new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $password);
    } catch (PDOException $e) {
        die("Error de conexión: " . $e->getMessage());
    }
}

function obtenerPlatosDisponibles() {
    $db = conectar();
    $stmt = $db->query("SELECT id, nombre, precio FROM plato WHERE cantidad > 0");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function obtenerPlatoPorId($id) {
    $db = conectar();
    $stmt = $db->prepare("SELECT id, nombre, precio FROM plato WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}
?>
